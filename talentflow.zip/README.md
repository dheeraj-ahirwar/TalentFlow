# TalentFlow — Mini Hiring Platform (Frontend)

## Quick start

1. Extract the ZIP.
2. `cd talentflow`
3. `npm install`
4. `npm run dev`
5. Open http://localhost:5173

This is a frontend-only demo that uses MSW + IndexedDB (Dexie) to simulate a backend.
